#include <stdio.h>

void print_env_vars();
void showsomething(){
    printf("Hmm it showed something\n");
}